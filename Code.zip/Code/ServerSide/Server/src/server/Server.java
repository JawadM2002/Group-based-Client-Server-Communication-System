/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package server;

import server.models.Client;
import server.models.Message;
import server.observer.EventManager;

import java.io.*;
import java.net.*;
import java.util.*;

/**
 * @author Jmbin
 */
public class Server {

    UIFacade uiFacade;
    EventManager eventManager;
    ServerSocket ss;
    ConnectionSingleton connectionInstance;

    public Server() {
        try {
            uiFacade = new UIFacade();
            eventManager = new EventManager();
            connectionInstance = ConnectionSingleton.getInstance();
            ss = new ServerSocket(2089);
            uiFacade.setStatusForSuccessfulConnection();

            new ClientAccept().start();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    class ClientAccept extends Thread {
        public void run() {
            while (true) {
                try {
                    Socket s = ss.accept(); // if client joins server, then the socket will use the accept method to get client that joins
                    String proposedClientId = new DataInputStream(s.getInputStream()).readUTF(); //a b c d => "a,b,c".split(",")
                    if (connectionInstance.isClientExisting(proposedClientId)) {
                        DataOutputStream dout = new DataOutputStream(s.getOutputStream()); // if client exists, it will display a message that the client is already registered
                        dout.writeUTF("Already Registered..!");
                    } else { // 
                        String ids = String.join(",", connectionInstance.getAllClientIds());
                        DataOutputStream dout = new DataOutputStream(s.getOutputStream());
                        dout.writeUTF("");
                        dout.writeUTF(ids); // send list of existing clients to the newly joined Client
                        new ObjectOutputStream(s.getOutputStream()).writeObject(connectionInstance.getAllBroadcastMessages()); // send list of all messages

                        Client proposedClient = new Client(proposedClientId, s); // passes down Client ID
                        connectionInstance.addClient(proposedClientId, proposedClient); // adds client ID

                        new MsgRead(proposedClient).start();
                        eventManager.notify("join", proposedClientId);  // notifies that the client has joined the server
                        eventManager.subscribe(proposedClientId);  
                        uiFacade.addContentToMsgBox(proposedClientId + " Joined! \n");
                        if(connectionInstance.getAllClientIds().size() == 1){
                            uiFacade.addContentToMsgBox(proposedClientId + " is the coordinator\n"); // for the first client that joins server

                        }

                    }
                } catch (Exception ex) {
                    ex.printStackTrace(); 
                }
            }
        }
    }

    class MsgRead extends Thread {
        Client client;

        MsgRead(Client client) {
            this.client = client;
        }

        public void run() {
            while (connectionInstance.hasClient()) {
                try {
                    String messageContent = new DataInputStream(client.getSocket().getInputStream()).readUTF();

                    if (messageContent.equals("mkoihgteazdcvgyhujb096785542AXTY")) {
                        // Client is leaving the chat
                        throw new Exception("default exit"); // exception handles quiting by default
                    }
                    else {
                        for (String key : connectionInstance.getAllClientIds()) {
                            if (!key.equalsIgnoreCase(client.getClientId())) {
                                try {
                                    new Message(client, connectionInstance.getClient(key), messageContent).sendMessage();
                                } catch (Exception ex) {
                                    connectionInstance.removeClient(key);
                                    uiFacade.addContentToMsgBox(key + " has been removed\n");
                                    uiFacade.addContentToMsgBox(connectionInstance.getCoordinatorId() + " is the new coordinator\n"); // automatic allocation of new coordinator

                                    eventManager.unsubscribe(client.getClientId()); // client is removed
                                    eventManager.notify("leave", client.getClientId()); // notifies that a client has left the chat

                                }
                            }
                        }
                        Message broadcastMessage = new Message(client, null, messageContent);
                        connectionInstance.addMessage(broadcastMessage);
                        uiFacade.addContentToMsgBox(client.getClientId() + ": " + messageContent + "\n");
                    }
                } catch (Exception ex) {
                    //handles existing of client from server
                    connectionInstance.removeClient(client.getClientId());
                    uiFacade.addContentToMsgBox(client.getClientId() + " has been removed\n");
                    uiFacade.addContentToMsgBox(connectionInstance.getCoordinatorId() + " is the new coordinator\n");

                    eventManager.unsubscribe(client.getClientId());
                    eventManager.notify("leave", client.getClientId());
                    return;

                }
            }
        }

        private void sendMsg(String id, String msg) throws IOException {
            new DataOutputStream(((Socket) connectionInstance.getClient(id).getSocket()).getOutputStream()).writeUTF(msg);
        }
    }


    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Server();
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables

    // End of variables declaration//GEN-END:variables
}
