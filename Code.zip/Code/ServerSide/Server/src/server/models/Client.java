package server.models;

import java.net.Socket;

public class Client {
    private String clientId;
    private Socket socket;


    public Client(String clientId, Socket socket) {
        this.clientId = clientId;
        this.socket = socket;
    }


    public String getClientId() {
        return clientId;
    }

    public Socket getSocket() {
        return socket;
    }
}
