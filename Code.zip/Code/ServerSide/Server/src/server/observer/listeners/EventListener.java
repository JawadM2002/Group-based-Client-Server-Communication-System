package server.observer.listeners;

import server.ConnectionSingleton;

import java.io.IOException;

public abstract class EventListener {
    protected String clientId;
    protected String eventType;
    protected ConnectionSingleton connectionSingleton;
    public String getClientId() {
        return clientId;
    }

    public String getEventType() {
        return eventType;
    }

    public EventListener(String clientId, String eventType) {
        this.clientId = clientId;
        this.eventType = eventType;
        this.connectionSingleton = ConnectionSingleton.getInstance();
    }

    public abstract void handleEvent(String data) throws IOException;
}
