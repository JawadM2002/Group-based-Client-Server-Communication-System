package server.observer;


import server.observer.listeners.ClientJoinListener;
import server.observer.listeners.ClientLeaveListener;
import server.observer.listeners.EventListener;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class EventManager {
    List<EventListener> listeners;
    HashMap<String, List<EventListener>> clientListenersMapping = new HashMap<>();


    public EventManager() {
        listeners = new ArrayList<>();
    }

    public void subscribe(String clientId) {
        List<EventListener> cls = Arrays.asList(
                new ClientJoinListener(clientId),
                new ClientLeaveListener(clientId)
        );
        this.listeners.addAll(cls);
        this.clientListenersMapping.put(clientId, cls);
    }

    public void unsubscribe(String clientId) {
        List<EventListener> cls = this.clientListenersMapping.get(clientId);
        this.listeners.removeAll(cls);
    }

    public void notify(String type, String data) {
        for (EventListener el : listeners) {
            if(el.getEventType().equals(type)){
                try {
                    el.handleEvent(data);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}
